#  Part of mcresources by Alex O'Neill
#  Work under copyright. Licensed under GPL-3.0
#  For more information see the project LICENSE file

from mcresources.mc113 import ResourceManager, clean_generated_resources
